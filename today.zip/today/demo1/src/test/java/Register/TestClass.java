package Register;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.StudentRegistrationPageFactory;

public class TestClass {
	private WebDriver driver;
	private StudentRegistrationPageFactory loginPageFactory;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\bdd\\chromedriver_win32\\\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^User is on 'Registration' Page$")
	public void user_is_on_Registration_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
        driver.get("file:///D:\\bdd\\\\demo1\\bishal.html");
		
		//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			loginPageFactory = new StudentRegistrationPageFactory(driver);
	}

	@When("^user enters invalid Name$")
	public void user_enters_invalid_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		loginPageFactory.setName("");;
		loginPageFactory.setLoginButton();
	}

	@Then("^display 'Please Enter Name'$")
	public void display_Please_Enter_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		String expectedMessage="* Please enter Name.";
		String actualMessage=loginPageFactory.getNameError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1000);
		driver.close();	}

	@When("^user enters invalid Address$")
	public void user_enters_invalid_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		loginPageFactory.setName("bishal");
		loginPageFactory.setAddress("");
		loginPageFactory.setLoginButton();
	}

	@Then("^display 'Please Enter Addresss'$")
	public void display_Please_Enter_Addresss() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String expectedMessage="* Please enter Address.";
		String actualMessage=loginPageFactory.getAddressError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1000);
		driver.close();	
	}

	@When("^user enters invalid Marks$")
	public void user_enters_invalid_Marks() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		loginPageFactory.setName("bishal");
		loginPageFactory.setAddress("pune");
		loginPageFactory.setMarks("");
		loginPageFactory.setLoginButton();
	}

	@Then("^display 'Please Enter Marks'$")
	public void display_Please_Enter_Marks() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String expectedMessage="* Please enter Marks.";
		String actualMessage=loginPageFactory.getMarksError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1000);
		driver.close();
	}

	

	@When("^user enters invalid details$")
	public void user_enters_invalid_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		loginPageFactory.setName("bishal");
		loginPageFactory.setAddress("pune");
		loginPageFactory.setMarks("123");
		loginPageFactory.setLoginButton();
	}

	@Then("^display 'Invalid Login Please try again'$")
	public void display_Invalid_Login_Please_try_again() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Invalid Login Please try again");
		
		
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //hrow new PendingException();
		loginPageFactory.setName("Bishal");
		loginPageFactory.setAddress("Pune");
		loginPageFactory.setMarks("124");
		loginPageFactory.setLoginButton();
	}

	@Then("^display 'success' Page$")
	public void display_success_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		Thread.sleep(1000);
		driver.get("D:\\bdd\\demo1\\success.html");
	}


}
